package problems;

import adt.bst.BST;

public class BSTSumLeavesImpl implements BSTSumLeaves{
    public int sumLeaves(BST<Integer> bst){
        //TODO implement your code here
        throw new UnsupportedOperationException("Not implemented yet!");
    }
}
