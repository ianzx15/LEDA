package adt.heap.extended;


import java.util.List;
import java.util.PriorityQueue;

public class HeapMergeImpl extends PriorityQueue<Integer> implements HeapMerge {

	@Override
	public Integer[] mergeArraysAndOrder(List<Integer[]> arrays) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public int sumRange(int k1, int k2) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

}
