package adt.hashtable.open;

import adt.hashtable.hashfunction.HashFunctionClosedAddressMethod;
import adt.hashtable.hashfunction.HashFunctionLinearProbing;

public class HashtableOpenAddressLinearProbingImpl<T extends Storable> extends
		AbstractHashtableOpenAddress<T> {

	public HashtableOpenAddressLinearProbingImpl(int size,
			HashFunctionClosedAddressMethod method) {
		super(size);
		hashFunction = new HashFunctionLinearProbing<T>(size, method);
		this.initiateInternalTable(size);
	}

	private int hash(T element, int probe){
		return ((HashFunctionLinearProbing) this.hashFunction).hash(element, probe);
	}

	@Override
	public void insert(T element) {
		if (isFull()){
			throw new HashtableOverflowException();
		}

		if (element != null && this.search(element) == null){
			boolean inserted = false;
			int probe = 0;

			while(probe < this.table.length && !inserted){
				int hashElement = hash(element, probe);

				if (this.table[hashElement] == null || this.table[hashElement].equals(new DELETED())){
					this.table[hashElement] = element;
					this.elements++; 
					inserted = true;
				} else{
					this.COLLISIONS++;
					probe++;
				}

			}
		}
	}

	@Override
	public void remove(T element) {
		if (element != null && !(this.isEmpty())) {
            boolean found = false;
            int i = 0;
            while (!found && i < this.table.length) {
                int hashElement = this.hash(element, i);

                if (this.table[hashElement] == null) {
                    found = true;
                } else if (this.table[hashElement].equals(element)) {
                    this.table[hashElement] = this.deletedElement;
                    found = true;
                    this.elements--;
                    this.COLLISIONS -= i;
                }

                i++;
            }
        }		
	}

	@Override
	public T search(T element) {
		T result = null;
        if (element != null && !isEmpty()) {
            int index = this.indexOf(element);
            if (index != -1) {
                result = (T) this.table[index];
            }
        }

        return result;
	}

	@Override
	public int indexOf(T element) {
		int index = -1;
		if (element != null && !this.isEmpty()){
			Boolean iguais = false;
			int probe = 0;
			while (index < this.table.length && !iguais){
				int hashElement = this.hash(element, probe++);
				if (this.table[hashElement] == null || this.table[hashElement].equals(this.deletedElement)){
					iguais = true;
				} else if (this.table[hashElement].equals(element) ){
					iguais = true;
					index = hashElement;
				}
			}
		}
		return index;
	}
}
