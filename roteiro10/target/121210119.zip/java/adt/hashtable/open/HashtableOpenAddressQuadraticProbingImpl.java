package adt.hashtable.open;

import adt.hashtable.hashfunction.HashFunctionClosedAddressMethod;
import adt.hashtable.hashfunction.HashFunctionQuadraticProbing;

public class HashtableOpenAddressQuadraticProbingImpl<T extends Storable>
		extends AbstractHashtableOpenAddress<T> {

	public HashtableOpenAddressQuadraticProbingImpl(int size,
			HashFunctionClosedAddressMethod method, int c1, int c2) {
		super(size);
		hashFunction = new HashFunctionQuadraticProbing<T>(size, method, c1, c2);
		this.initiateInternalTable(size);
	}
	private int hash(T element, int probe){
		return ((HashFunctionQuadraticProbing) this.hashFunction).hash(element, probe);
	}
	@Override
	public void insert(T element) {
		if (isFull()){
			throw new HashtableOverflowException();
		}

		if (element != null && this.search(element) == null){
			boolean inserted = false;
			int probe = 0;

			while(probe < this.table.length && !inserted){
				int hashElement = hash(element, probe);

				if (this.table[hashElement] == null || this.table[hashElement].equals(new DELETED())){
					this.table[hashElement] = element;
					this.elements++; 
					inserted = true;
				} else{
					this.COLLISIONS++;
					probe++;
				}

			}
		}
	}

	@Override
	public void remove(T element) {
		if (element != null && !isEmpty()) {
            int hash;
            boolean found = false;
            int i = 0;
            while (!found && i < this.table.length) {
                hash = this.hash(element, i);
                if (this.table[hash] == null) {
                    found = true;
                } else if (this.table[hash].equals(element)) {
                    this.table[hash] = this.deletedElement;
                    found = true;
                    this.elements--;
                    this.COLLISIONS -= i;
                }

                i++;
            }
        }	

	}

	@Override
	public T search(T element) {
		T result = null;
        if (element != null && !isEmpty()) {
            int index = this.indexOf(element);
            if (index != -1) {
                result = (T) this.table[index];
            }
        }
        return result;
	}

	@Override
	public int indexOf(T element) {
		int index = -1;
        if (element != null && !isEmpty()) {
            boolean found = false;
            int i = 0;
            while (!found && i < this.table.length) {
                int hashElement = this.hash(element, i++);
                if (this.table[hashElement] == null || this.table[hashElement].equals(this.deletedElement)) {
                    found = true;
                } else if (this.table[hashElement].equals(element)) {
                    index = hashElement;
                    found = true;
                }

            }
        }

        return index;
    }
}
