package Formas;

public interface Formas {

    public double area();

}
